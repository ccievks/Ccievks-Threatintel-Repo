# Known Compromised Packages - Shai-Hulud Attack

This document tracks known compromised packages from the Shai-Hulud NPM supply chain attack.

## Attack Overview

- **Attack Name**: Shai-Hulud (Self-Replicating Worm)
- **Discovery Date**: September 15, 2025
- **Total Packages Affected**: 500+ NPM packages
- **Primary Target**: @ctrl/tinycolor (2M+ weekly downloads)
- **Attack Type**: Self-replicating worm, credential harvesting, GitHub Actions backdoor

## Advisory Sources

1. **StepSecurity Blog**: https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised
2. **Semgrep Security Advisory**: https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/
3. **JFrog Security Research**: https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/
4. **Socket.dev Blog**: https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages
5. **Wiz Security Blog**: https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack

## Known Compromised Packages

### Primary Package
- **@ctrl/tinycolor** - Primary target, 2M+ weekly downloads

### Additional Packages
*Note: The attack compromised 500+ packages total. Specific package names should be added here as they are identified in the advisories.*

To add packages, edit `security_advisories.py` and add them to the `shai_hulud_packages` list in the `load_known_compromised_packages()` method.

## Attack Characteristics

The malware:
- Self-replicates to other packages owned by the same maintainer
- Harvests AWS/GCP/Azure credentials using TruffleHog
- Establishes persistence through GitHub Actions backdoors
- Exfiltrates credentials to webhook.site endpoints
- Creates malicious GitHub repositories named "Shai-Hulud"
- Targets Linux/macOS development environments

## Detection

The Shai-Hulud Detector checks for:
- Known compromised package names
- Suspicious code patterns (eval, exec, base64 decode, etc.)
- Package integrity issues
- Suspicious files in site-packages

## Remediation

If you find compromised packages:
1. **Immediately rotate ALL credentials**:
   - NPM tokens
   - GitHub personal access tokens
   - GitHub Actions secrets
   - AWS/GCP/Azure credentials
   - SSH keys

2. **Remove compromised packages**:
   ```bash
   npm uninstall <package-name>
   ```

3. **Audit cloud infrastructure** for unauthorized access

4. **Review GitHub repositories** for malicious workflows

5. **Check for malicious branches** named "shai-hulud"

## Updating This List

As new packages are identified in the advisories, they can be added using:

### Method 1: Using the Helper Script (Recommended)
```bash
python add_compromised_packages.py --source "StepSecurity Blog" --notes "Shai-Hulud attack" package-name-1 package-name-2
```

### Method 2: Manual Edit
Edit `security_advisories.py` and add packages to the `shai_hulud_packages` list in the `load_known_compromised_packages()` method.

### Method 3: Direct Cache Edit
Edit `.cache/compromised_packages.json` directly (not recommended, use Method 1 instead).

## References

- [StepSecurity Blog - Shai-Hulud Analysis](https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised)
- [Semgrep Security Advisory](https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/)
- [JFrog Security Research](https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/)
- [Socket.dev Blog](https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages)
- [Wiz Security Blog](https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack)

