# Changelog

## Version 2.0 - Focused Reporting (Current)

### Changed
- **Report now only shows compromised packages**: The detector now filters out pattern-based findings for legitimate packages
- Only reports packages that match known compromised packages from security advisories
- Eliminates false positives from well-known packages (anyio, boto3, cffi, etc.)
- Cleaner, more actionable reports

### Benefits
- **Less confusion**: Users only see actual threats, not false positives
- **Faster review**: Focus on real compromised packages
- **Clearer output**: Report clearly indicates if no compromised packages found

### Report Structure
- `compromised_packages_found`: Number of packages matching security advisories
- `compromised_packages`: List of compromised packages with details
- `findings`: Only includes findings related to compromised packages
- `note`: Explains that pattern-based findings are filtered out

## Version 1.0 - Initial Release

### Features
- Package scanning with pattern detection
- Security advisories integration
- Package integrity checking
- Site-packages scanning
- Environment variable checking
- JSON report generation

