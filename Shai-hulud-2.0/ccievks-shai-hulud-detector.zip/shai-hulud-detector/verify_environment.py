#!/usr/bin/env python3
"""
Quick verification script to check if the environment is safe to run the detector.
This script uses only standard library and checks for basic security issues.
"""

import sys
import os
import subprocess

def check_python_version():
    """Check Python version"""
    if sys.version_info < (3, 7):
        print("ERROR: Python 3.7+ required")
        return False
    print(f"✓ Python version: {sys.version.split()[0]}")
    return True

def check_standard_library_only():
    """Verify we're using standard library only"""
    try:
        import json
        import hashlib
        import subprocess
        import importlib
        print("✓ Standard library modules available")
        return True
    except ImportError as e:
        print(f"ERROR: Missing standard library module: {e}")
        return False

def check_pip_available():
    """Check if pip is available"""
    try:
        result = subprocess.run(
            [sys.executable, '-m', 'pip', '--version'],
            capture_output=True,
            timeout=5
        )
        if result.returncode == 0:
            print(f"✓ pip available: {result.stdout.decode().strip()}")
            return True
        else:
            print("WARNING: pip not available")
            return False
    except Exception as e:
        print(f"WARNING: Could not check pip: {e}")
        return False

def check_suspicious_imports():
    """Check for suspicious imports in current environment"""
    suspicious_modules = ['crypto', 'encryption', 'secure']
    found = []
    
    for module in suspicious_modules:
        try:
            __import__(module)
            found.append(module)
        except ImportError:
            pass
    
    if found:
        print(f"WARNING: Found potentially suspicious modules: {found}")
        return False
    else:
        print("✓ No suspicious modules found in import path")
        return True

def main():
    """Run verification checks"""
    print("=" * 60)
    print("Environment Verification for Shai-Hulud Detector")
    print("=" * 60)
    print()
    
    checks = [
        ("Python Version", check_python_version),
        ("Standard Library", check_standard_library_only),
        ("Pip Availability", check_pip_available),
        ("Suspicious Imports", check_suspicious_imports),
    ]
    
    all_passed = True
    for name, check_func in checks:
        print(f"Checking {name}...")
        if not check_func():
            all_passed = False
        print()
    
    print("=" * 60)
    if all_passed:
        print("✓ Environment verification passed")
        print("Safe to run shai_hulud_detector.py")
        return 0
    else:
        print("⚠ Environment verification found issues")
        print("Review warnings before running detector")
        return 1

if __name__ == '__main__':
    sys.exit(main())

