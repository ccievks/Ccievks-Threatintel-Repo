# Quick Start Guide - Shai-Hulud Detector

## Step 1: Verify Your Environment (Recommended)

Before running the detector, verify your environment is safe:

```bash
cd shai-hulud-detector
python3 verify_environment.py
```

This checks:
- Python version compatibility
- Standard library availability
- Pip availability
- Suspicious imports

## Step 2: Update Security Advisories Database (Optional but Recommended)

Update the compromised packages database from security advisories:

```bash
python3 update_advisories.py
```

This will:
- Fetch latest compromised packages from all advisory sources
- Cache the results locally (`.cache/compromised_packages.json`)
- Take a few minutes depending on network speed

**Note**: This requires internet connection. If you're offline, the detector will use cached data if available.

## Step 3: Run the Full Security Scan

Run the complete malware detection scan:

```bash
python3 shai_hulud_detector.py
```

This will:
1. Update security advisories (if enabled)
2. Check all installed packages against compromised packages database
3. **Only report known compromised packages** (filters out false positives)
4. If compromised packages found, run additional security checks
5. Generate a detailed JSON report

**Important**: The report only shows compromised packages from security advisories. Pattern-based findings for legitimate packages (like anyio, boto3, etc.) are filtered out to avoid confusion.

## Output

The scan produces:
- **Console output**: Real-time findings with severity levels
- **JSON report**: `shai_hulud_report_YYYYMMDD_HHMMSS.json` with complete details

## Example Output

```
============================================================
Shai-Hulud Detector - Malware Detection Scan
============================================================
Scan started at: 2024-12-19T10:30:00

Step 0: Updating security advisories database...
Checking StepSecurity Blog...
Checking Semgrep Security Advisory...
...
Compromised packages in database: 1

Step 1: Retrieving installed packages...
Found 150 installed packages

Step 2: Scanning packages for suspicious content...
Scanning: requests (2.31.0)
Scanning: numpy (1.24.3)
...

[CRITICAL] Security Advisory: Package @ctrl/tinycolor found in compromised packages database
  source: StepSecurity Blog - Shai-Hulud Attack

============================================================
Scan Complete - Generating Report
============================================================

Summary:
  Packages scanned: 150
  Total findings: 5
  Findings by severity:
    CRITICAL: 1
    HIGH: 2
    MEDIUM: 2

Detailed report saved to: shai_hulud_report_20241219_103045.json
```

## Additional Tools

### Add Compromised Packages Manually

If you find specific compromised packages in advisories:

```bash
python3 add_compromised_packages.py --source "StepSecurity Blog" --notes "Shai-Hulud attack" package-name-1 package-name-2
```

### Test Security Advisories Checker

Test the advisories checker independently:

```bash
python3 security_advisories.py
```

## Exit Codes

- `0`: No critical findings
- `1`: High severity findings detected
- `2`: Medium severity findings detected

## Troubleshooting

### No Internet Connection
The detector will use cached data if available. If no cache exists, it will skip advisory checks but still perform local scans.

### Permission Errors
If you get permission errors, you may need to run with appropriate permissions:
```bash
sudo python3 shai_hulud_detector.py
```

### Missing Modules
The detector uses only Python standard library. If you see import errors, check your Python installation.

## Next Steps After Detection

If compromised packages are found:

1. **Immediately rotate ALL credentials** (NPM, GitHub, AWS, GCP, Azure)
2. **Remove compromised packages**: `pip uninstall <package-name>`
3. **Audit cloud infrastructure** for unauthorized access
4. **Review GitHub repositories** for malicious workflows
5. **Check for malicious branches** named "shai-hulud"

See `KNOWN_COMPROMISED_PACKAGES.md` for detailed remediation steps.

