# Security Advisories Integration

The Shai-Hulud Detector checks installed packages against known compromised packages from multiple security advisory sources.

## Supported Sources

1. **StepSecurity Blog** - Comprehensive analysis of compromised packages
   - URL: https://blog.stepsecurity.io

2. **Semgrep Security Advisory** - Detailed technical analysis
   - URL: https://semgrep.dev/blog, https://semgrep.dev/security

3. **JFrog Security Research** - Ongoing detection of new packages
   - URL: https://research.jfrog.com

4. **Wiz Security Blog** - Attack analysis with package appendix
   - URL: https://www.wiz.io/blog, https://www.wiz.io/security

5. **Socket.dev Blog** - CrowdStrike package analysis
   - URL: https://socket.dev/blog, https://socket.dev/security

## How It Works

1. **Caching**: The tool maintains a local cache (`.cache/compromised_packages.json`) to avoid repeated network requests
2. **Automatic Updates**: Cache is refreshed daily (configurable)
3. **Package Matching**: Checks both exact matches and partial matches (typosquatting detection)
4. **Integration**: Automatically checks all installed packages during scan

## Usage

### Automatic Check (During Scan)
The security advisories check runs automatically when you run:
```bash
python shai_hulud_detector.py
```

### Manual Update
To manually refresh the compromised packages database:
```bash
python update_advisories.py
```

### Standalone Check
To test the advisories checker:
```bash
python security_advisories.py
```

## Cache Management

- **Location**: `.cache/compromised_packages.json`
- **Refresh Interval**: 24 hours (default)
- **Force Refresh**: Use `update_advisories.py` with `force_refresh=True`

## Adding Known Compromised Packages

You can manually add known compromised packages by editing `security_advisories.py` and adding them to the `known_packages` dictionary in the `load_known_compromised_packages()` method:

```python
known_packages = {
    'malicious-package-name': {
        'source': 'Manual Entry',
        'first_seen': '2024-01-01T00:00:00',
        'notes': 'Known malicious package description'
    }
}
```

## Limitations

- **Network Required**: Requires internet connection to fetch advisories
- **Content Parsing**: Uses pattern matching to extract package names from web content
- **Rate Limiting**: Respects website rate limits (may need manual updates if blocked)
- **False Positives**: Pattern matching may occasionally match non-package text

## Security Note

This tool uses only Python standard library (`urllib`) to fetch advisories, avoiding the need to install potentially compromised packages like `requests` or `beautifulsoup4`.

