# Update Process - Compromised Packages Database

## How the Update Process Works

### Step 1: Load Known Packages (Always First)
Before any scanning or web fetching, the detector **always** loads the hardcoded list of known compromised packages from `security_advisories.py`. This ensures:

- ✅ Known packages (like `@ctrl/tinycolor`) are **always** included
- ✅ Known packages take precedence over cached data
- ✅ The list is updated from the 5 security advisory sources you provided

### Step 2: Check Cache
If cache exists and is fresh (< 24 hours old):
- Load cached packages from web sources
- Merge with known packages (known packages take precedence)
- Skip web fetching to save time

### Step 3: Fetch from 5 Sources (If Needed)
If cache is stale or missing, fetch from all 5 sources:

1. **StepSecurity Blog**
   - URL: https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised
   - Extracts package names from the page

2. **Semgrep Security Advisory**
   - URL: https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/
   - Extracts package names from the page

3. **JFrog Security Research**
   - URL: https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/
   - Extracts package names from the page

4. **Wiz Security Blog**
   - URL: https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack
   - Extracts package names from the page

5. **Socket.dev Blog**
   - URL: https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages
   - Extracts package names from the page

### Step 4: Save Cache
After fetching, save all packages (known + web sources) to cache for future use.

## Known Packages List

The known packages are hardcoded in `security_advisories.py` in the `load_known_compromised_packages()` method. Currently includes:

- `@ctrl/tinycolor` - Primary target from Shai-Hulud attack

To add more known packages, edit the `known_packages` dictionary in that method.

## Verification

The update process shows:
- Number of known packages loaded
- Number of packages found from each source
- Total packages in database
- Breakdown of known vs. web-sourced packages

## Manual Update

To force a fresh update from all sources:

```bash
python3 update_advisories.py
```

Or in the detector:

```bash
python3 shai_hulud_detector.py
# It will automatically update if cache is stale
```

