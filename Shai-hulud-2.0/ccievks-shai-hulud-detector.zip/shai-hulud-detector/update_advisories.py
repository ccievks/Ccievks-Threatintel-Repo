#!/usr/bin/env python3
"""
Standalone script to update security advisories database.
Can be run separately to refresh the compromised packages database.
"""

from security_advisories import SecurityAdvisoriesChecker

def main():
    print("=" * 60)
    print("Security Advisories Database Updater")
    print("=" * 60)
    print()
    
    checker = SecurityAdvisoriesChecker()
    
    # Force refresh from all sources
    count = checker.update_advisories(force_refresh=True)
    
    print(f"\n✓ Database updated with {count} compromised packages")
    print(f"Cache location: {checker.cache_file}")
    
    # Show some examples
    all_packages = checker.get_all_compromised_packages()
    if all_packages:
        print(f"\nSample compromised packages:")
        for i, (pkg, info) in enumerate(list(all_packages.items())[:10]):
            print(f"  - {pkg} (Source: {info.get('source', 'Unknown')})")
        if len(all_packages) > 10:
            print(f"  ... and {len(all_packages) - 10} more")

if __name__ == '__main__':
    main()

