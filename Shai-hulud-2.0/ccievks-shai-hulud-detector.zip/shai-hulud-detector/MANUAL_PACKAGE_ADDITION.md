# Manual Package Addition Guide

## Why Manual Addition is Needed

The web scraping from security advisory sources may not always work due to:
- SSL certificate verification issues
- JavaScript-rendered content
- Rate limiting or access restrictions
- Package names in formats not easily extractable

**Therefore, it's important to manually add known compromised packages from the 5 sources.**

## The 5 Security Advisory Sources

1. **StepSecurity Blog**: https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised
2. **Semgrep Security Advisory**: https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/
3. **JFrog Security Research**: https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/
4. **Wiz Security Blog**: https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack
5. **Socket.dev Blog**: https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages

## How to Add Packages

### Method 1: Using the Helper Script (Recommended)

```bash
cd /Users/username/Downloads/Cursor/shai-hulud-detector

# Add single package
python3 add_compromised_packages.py --source "StepSecurity Blog" --notes "Shai-Hulud attack" @ctrl/tinycolor

# Add multiple packages
python3 add_compromised_packages.py --source "StepSecurity Blog" --notes "Shai-Hulud attack" package1 package2 package3
```

### Method 2: Edit security_advisories.py Directly

Edit `security_advisories.py` and add packages to the `known_packages` dictionary:

```python
known_packages = {
    '@ctrl/tinycolor': {
        'source': 'StepSecurity Blog - Shai-Hulud Attack',
        'first_seen': '2025-09-15T00:00:00',
        'notes': 'Primary target, 2M+ weekly downloads, self-replicating worm',
        'advisory_url': 'https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised'
    },
    # Add more packages here:
    'package-name-2': {
        'source': 'StepSecurity Blog - Shai-Hulud Attack',
        'first_seen': '2025-09-15T00:00:00',
        'notes': 'Compromised in Shai-Hulud attack',
        'advisory_url': 'https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised'
    },
}
```

Or add to the `shai_hulud_packages` list:

```python
shai_hulud_packages = [
    '@ctrl/tinycolor',  # Already added
    'package-name-1',
    'package-name-2',
    # Add more here
]
```

## Finding Package Names from Sources

### Step 1: Visit Each Advisory Source
Open each of the 5 URLs in your browser.

### Step 2: Look for Package Lists
The advisories typically list compromised packages in:
- Tables
- Bulleted lists
- Code blocks
- JSON structures
- Appendix sections

### Step 3: Extract Package Names
Copy package names exactly as they appear (including @scope for npm packages).

### Step 4: Add to Database
Use the helper script or edit the file directly.

## Current Status

**Known Packages (Hardcoded):**
- `@ctrl/tinycolor` - StepSecurity Blog

**To Do:**
- Extract remaining 39+ packages from StepSecurity blog
- Extract packages from Semgrep advisory
- Extract packages from JFrog research
- Extract packages from Wiz blog
- Extract packages from Socket.dev blog

## Verification

After adding packages, verify they're loaded:

```bash
python3 -c "
from security_advisories import SecurityAdvisoriesChecker
checker = SecurityAdvisoriesChecker()
checker.update_advisories(force_refresh=False)
packages = checker.get_all_compromised_packages()
print(f'Total packages: {len(packages)}')
for pkg in sorted(packages.keys()):
    print(f'  - {pkg}')
"
```

## Important Notes

1. **Always update before scanning**: The detector automatically updates before each scan
2. **Known packages take precedence**: Hardcoded packages always override cached data
3. **Package names must match exactly**: Use exact package names as they appear in advisories
4. **Include @scope for npm packages**: e.g., `@ctrl/tinycolor` not just `tinycolor`

## Next Steps

1. Visit each of the 5 advisory sources
2. Extract all compromised package names
3. Add them using the helper script or by editing the file
4. Verify the packages are loaded
5. Run the detector to check your environment

