#!/usr/bin/env python3
"""
Helper script to add compromised packages to the database.
This script helps manually add packages discovered in security advisories.
"""

import json
import sys
from pathlib import Path
from datetime import datetime

def load_current_packages():
    """Load current compromised packages from cache"""
    cache_file = Path('.cache/compromised_packages.json')
    if cache_file.exists():
        with open(cache_file, 'r') as f:
            data = json.load(f)
            return data.get('packages', {})
    return {}

def add_packages(package_list, source='Manual Entry', notes=''):
    """Add packages to the compromised packages database"""
    packages = load_current_packages()
    added = 0
    
    for pkg in package_list:
        pkg_lower = pkg.lower().strip()
        if not pkg_lower:
            continue
            
        if pkg_lower not in packages:
            packages[pkg_lower] = {
                'source': source,
                'first_seen': datetime.now().isoformat(),
                'notes': notes
            }
            added += 1
            print(f"✓ Added: {pkg_lower}")
        else:
            print(f"⊘ Already exists: {pkg_lower}")
    
    # Save updated packages
    cache_file = Path('.cache/compromised_packages.json')
    cache_file.parent.mkdir(exist_ok=True)
    
    data = {
        'last_updated': datetime.now().isoformat(),
        'packages': packages
    }
    
    with open(cache_file, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"\n✓ Added {added} new packages")
    print(f"Total packages in database: {len(packages)}")
    print(f"Cache saved to: {cache_file}")

def main():
    """Main function"""
    print("=" * 60)
    print("Add Compromised Packages to Database")
    print("=" * 60)
    print()
    
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python add_compromised_packages.py <package1> [package2] [package3] ...")
        print()
        print("Options:")
        print("  --source <source>    Set source (default: 'Manual Entry')")
        print("  --notes <notes>      Add notes about the packages")
        print()
        print("Example:")
        print("  python add_compromised_packages.py @ctrl/tinycolor package-name-2")
        print("  python add_compromised_packages.py --source 'StepSecurity Blog' --notes 'Shai-Hulud attack' pkg1 pkg2")
        sys.exit(1)
    
    # Parse arguments
    packages = []
    source = 'Manual Entry'
    notes = ''
    
    i = 1
    while i < len(sys.argv):
        arg = sys.argv[i]
        if arg == '--source' and i + 1 < len(sys.argv):
            source = sys.argv[i + 1]
            i += 2
        elif arg == '--notes' and i + 1 < len(sys.argv):
            notes = sys.argv[i + 1]
            i += 2
        elif not arg.startswith('--'):
            packages.append(arg)
            i += 1
        else:
            i += 1
    
    if not packages:
        print("Error: No packages specified")
        sys.exit(1)
    
    print(f"Source: {source}")
    if notes:
        print(f"Notes: {notes}")
    print(f"Packages to add: {len(packages)}")
    print()
    
    add_packages(packages, source, notes)

if __name__ == '__main__':
    main()

