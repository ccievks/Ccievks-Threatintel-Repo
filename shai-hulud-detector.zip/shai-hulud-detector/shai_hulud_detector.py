#!/usr/bin/env python3
"""
Shai-Hulud Detector - Malware and Compromised Package Detection Tool

This tool scans your local environment for:
- Suspicious packages and files
- Compromised package installations
- Malware indicators
- Unauthorized modifications

Uses only Python standard library to avoid installing compromised packages.
"""

import os
import sys
import json
import hashlib
import subprocess
import importlib.util
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import re

# Import security advisories checker
try:
    from security_advisories import SecurityAdvisoriesChecker
    ADVISORIES_AVAILABLE = True
except ImportError:
    ADVISORIES_AVAILABLE = False
    print("Warning: security_advisories module not available")

class ShaiHuludDetector:
    """Main detector class for scanning and detecting malware"""
    
    def __init__(self, check_advisories=True):
        self.check_advisories = check_advisories and ADVISORIES_AVAILABLE
        if self.check_advisories:
            self.advisories_checker = SecurityAdvisoriesChecker()
        else:
            self.advisories_checker = None
        
        self.suspicious_patterns = [
            r'base64\.b64decode',
            r'eval\(',
            r'exec\(',
            r'__import__\(',
            r'compile\(',
            r'eval\(.*\)',
            r'exec\(.*\)',
            r'subprocess\.call',
            r'os\.system',
            r'os\.popen',
            r'urllib\.request\.urlopen',
            r'requests\.get',
            r'socket\.socket',
            r'pickle\.loads',
            r'yaml\.load',
            r'pickle\.load',
        ]
        
        self.suspicious_package_names = [
            'crypto', 'encryption', 'secure', 'safe', 'trust',
            'update', 'installer', 'helper', 'utils', 'tools'
        ]
        
        self.known_malicious_hashes = set()  # Can be populated with known bad hashes
        self.findings = []
        self.scanned_packages = []
        
    def log_finding(self, severity, category, message, details=None):
        """Log a security finding"""
        finding = {
            'timestamp': datetime.now().isoformat(),
            'severity': severity,
            'category': category,
            'message': message,
            'details': details or {}
        }
        self.findings.append(finding)
        print(f"[{severity}] {category}: {message}")
        if details:
            for key, value in details.items():
                print(f"  {key}: {value}")
    
    def get_installed_packages(self):
        """Get list of installed Python packages"""
        try:
            result = subprocess.run(
                [sys.executable, '-m', 'pip', 'list', '--format=json'],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                packages = json.loads(result.stdout)
                return packages
            else:
                self.log_finding('WARNING', 'Package Scan', 
                               'Could not retrieve package list', 
                               {'error': result.stderr})
                return []
        except Exception as e:
            self.log_finding('ERROR', 'Package Scan', 
                           'Failed to get installed packages', 
                           {'error': str(e)})
            return []
    
    def get_package_location(self, package_name):
        """Get installation location of a package"""
        try:
            result = subprocess.run(
                [sys.executable, '-m', 'pip', 'show', package_name],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Location:'):
                        return line.split(':', 1)[1].strip()
        except Exception as e:
            pass
        return None
    
    def calculate_file_hash(self, filepath):
        """Calculate SHA256 hash of a file"""
        try:
            with open(filepath, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
                return file_hash
        except Exception as e:
            return None
    
    def scan_file_for_suspicious_patterns(self, filepath):
        """Scan a file for suspicious code patterns"""
        suspicious_found = []
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                for pattern in self.suspicious_patterns:
                    if re.search(pattern, content, re.IGNORECASE):
                        suspicious_found.append(pattern)
        except Exception:
            pass
        return suspicious_found
    
    def scan_package(self, package_name, package_version):
        """Scan a single package for suspicious content"""
        package_info = {
            'name': package_name,
            'version': package_version,
            'location': None,
            'files_scanned': 0,
            'suspicious_files': [],
            'suspicious_patterns': [],
            'file_hashes': {},
            'advisory_check': None
        }
        
        # Check against security advisories
        if self.advisories_checker:
            advisory_result = self.advisories_checker.check_package(package_name)
            package_info['advisory_check'] = advisory_result
            if advisory_result.get('compromised'):
                self.log_finding('CRITICAL', 'Security Advisory', 
                               f'Package {package_name} found in compromised packages database',
                               {
                                   'source': advisory_result.get('info', {}).get('source', 'Unknown'),
                                   'match_type': advisory_result.get('match_type', 'exact')
                               })
        
        location = self.get_package_location(package_name)
        if not location:
            return package_info
        
        package_info['location'] = location
        package_path = Path(location) / package_name.replace('-', '_')
        
        if not package_path.exists():
            package_path = Path(location) / package_name
        
        if not package_path.exists():
            self.log_finding('WARNING', 'Package Scan', 
                           f'Package location not found: {package_name}')
            return package_info
        
        # Scan Python files in package
        for py_file in package_path.rglob('*.py'):
            if py_file.is_file():
                package_info['files_scanned'] += 1
                file_hash = self.calculate_file_hash(py_file)
                if file_hash:
                    package_info['file_hashes'][str(py_file)] = file_hash
                
                suspicious = self.scan_file_for_suspicious_patterns(py_file)
                if suspicious:
                    package_info['suspicious_files'].append(str(py_file))
                    package_info['suspicious_patterns'].extend(suspicious)
        
        # Only report findings if package is compromised according to advisories
        is_compromised = False
        if package_info.get('advisory_check', {}).get('compromised'):
            is_compromised = True
        
        # Only log suspicious patterns if package is compromised
        if is_compromised and package_info['suspicious_files']:
            self.log_finding('HIGH', 'Malware Detection', 
                           f'Suspicious patterns found in compromised package {package_name}',
                           {
                               'files': package_info['suspicious_files'],
                               'patterns': list(set(package_info['suspicious_patterns']))
                           })
        
        # Only report suspicious package name if compromised
        if is_compromised and any(susp in package_name.lower() for susp in self.suspicious_package_names):
            self.log_finding('MEDIUM', 'Package Name', 
                           f'Suspicious package name: {package_name}')
        
        return package_info
    
    def check_package_integrity(self, package_name):
        """Check package integrity using pip check"""
        try:
            result = subprocess.run(
                [sys.executable, '-m', 'pip', 'check'],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                self.log_finding('HIGH', 'Package Integrity', 
                               'Package integrity check failed',
                               {'output': result.stdout + result.stderr})
        except Exception as e:
            self.log_finding('WARNING', 'Package Integrity', 
                           'Could not run integrity check',
                           {'error': str(e)})
    
    def scan_site_packages(self):
        """Scan site-packages directory for suspicious files"""
        site_packages = None
        for path in sys.path:
            if 'site-packages' in path:
                site_packages = Path(path)
                break
        
        if not site_packages or not site_packages.exists():
            self.log_finding('WARNING', 'File Scan', 
                           'Could not find site-packages directory')
            return
        
        # Look for suspicious files
        suspicious_extensions = ['.exe', '.dll', '.so', '.dylib', '.bin']
        for ext in suspicious_extensions:
            for file_path in site_packages.rglob(f'*{ext}'):
                if file_path.is_file():
                    self.log_finding('MEDIUM', 'File Scan', 
                                   f'Binary file found in site-packages: {file_path}')
    
    def check_environment_variables(self):
        """Check for suspicious environment variables"""
        suspicious_vars = []
        env_vars_to_check = ['PYTHONPATH', 'PYTHONSTARTUP', 'PYTHONHOME']
        
        for var in env_vars_to_check:
            value = os.environ.get(var)
            if value:
                # Check for suspicious paths
                if any(susp in value.lower() for susp in ['temp', 'tmp', 'downloads']):
                    suspicious_vars.append(var)
        
        if suspicious_vars:
            self.log_finding('MEDIUM', 'Environment', 
                           'Suspicious environment variables detected',
                           {'variables': suspicious_vars})
    
    def generate_report(self):
        """Generate final security report - only includes compromised packages"""
        # Filter to only include compromised packages
        compromised_packages = []
        for pkg_info in self.scanned_packages:
            if pkg_info.get('advisory_check', {}).get('compromised'):
                compromised_packages.append(pkg_info)
        
        # Filter findings to only include compromised packages or critical issues
        filtered_findings = []
        for finding in self.findings:
            # Include CRITICAL findings (compromised packages from advisories)
            if finding['severity'] == 'CRITICAL':
                filtered_findings.append(finding)
            # Include HIGH findings only if they mention a compromised package
            elif finding['severity'] == 'HIGH':
                # Check if finding is about a compromised package
                message = finding.get('message', '')
                for comp_pkg in compromised_packages:
                    if comp_pkg['name'] in message:
                        filtered_findings.append(finding)
                        break
            # Include other findings only if they're about compromised packages
            else:
                message = finding.get('message', '')
                for comp_pkg in compromised_packages:
                    if comp_pkg['name'] in message:
                        filtered_findings.append(finding)
                        break
        
        report = {
            'scan_timestamp': datetime.now().isoformat(),
            'python_version': sys.version,
            'platform': sys.platform,
            'packages_scanned': len(self.scanned_packages),
            'compromised_packages_found': len(compromised_packages),
            'total_findings': len(filtered_findings),
            'findings_by_severity': defaultdict(int),
            'compromised_packages': compromised_packages,
            'findings': filtered_findings,
            'note': 'This report only includes known compromised packages from security advisories. Pattern-based findings for legitimate packages have been filtered out.'
        }
        
        for finding in filtered_findings:
            report['findings_by_severity'][finding['severity']] += 1
        
        return report
    
    def run_full_scan(self):
        """Run complete security scan"""
        print("=" * 60)
        print("Shai-Hulud Detector - Malware Detection Scan")
        print("=" * 60)
        print(f"Scan started at: {datetime.now().isoformat()}\n")
        
        # Update security advisories if enabled
        if self.check_advisories:
            print("Step 0: Updating compromised packages database...")
            print("  - Loading known compromised packages from hardcoded list")
            print("  - Fetching latest packages from 5 security advisory sources")
            print()
            total_packages = self.advisories_checker.update_advisories(force_refresh=False)
            print(f"\n✓ Compromised packages database ready: {total_packages} packages")
            print()
        
        # Get installed packages
        print("Step 1: Retrieving installed packages...")
        packages = self.get_installed_packages()
        print(f"Found {len(packages)} installed packages\n")
        
        # Scan each package
        print("Step 2: Scanning packages for suspicious content...")
        for pkg in packages:
            pkg_name = pkg.get('name', '')
            pkg_version = pkg.get('version', '')
            print(f"Scanning: {pkg_name} ({pkg_version})")
            package_info = self.scan_package(pkg_name, pkg_version)
            self.scanned_packages.append(package_info)
        
        # Only run additional checks if compromised packages found
        compromised_count = sum(1 for pkg in self.scanned_packages 
                               if pkg.get('advisory_check', {}).get('compromised'))
        
        if compromised_count > 0:
            print(f"\n⚠️  {compromised_count} compromised package(s) detected - running additional checks...")
            print("\nStep 3: Checking package integrity...")
            self.check_package_integrity('all')
            
            print("\nStep 4: Scanning site-packages for suspicious files...")
            self.scan_site_packages()
            
            print("\nStep 5: Checking environment variables...")
            self.check_environment_variables()
        else:
            print("\n✓ No compromised packages detected - skipping additional checks")
        
        # Generate report
        print("\n" + "=" * 60)
        print("Scan Complete - Generating Report")
        print("=" * 60)
        
        report = self.generate_report()
        
        # Print summary
        print(f"\nSummary:")
        print(f"  Packages scanned: {report['packages_scanned']}")
        print(f"  Compromised packages found: {report['compromised_packages_found']}")
        if report['compromised_packages_found'] > 0:
            print(f"\n  ⚠️  COMPROMISED PACKAGES DETECTED:")
            for pkg in report['compromised_packages']:
                advisory_info = pkg.get('advisory_check', {})
                source = advisory_info.get('info', {}).get('source', 'Unknown')
                print(f"    - {pkg['name']} ({pkg['version']})")
                print(f"      Source: {source}")
        print(f"\n  Total findings: {report['total_findings']}")
        if report['total_findings'] > 0:
            print(f"  Findings by severity:")
            for severity, count in report['findings_by_severity'].items():
                print(f"    {severity}: {count}")
        else:
            print(f"\n  ✓ No compromised packages detected!")
            print(f"  Note: Pattern-based findings for legitimate packages have been filtered out.")
        
        # Save report
        report_file = f"shai_hulud_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\nDetailed report saved to: {report_file}")
        
        return report


def main():
    """Main entry point"""
    detector = ShaiHuludDetector()
    report = detector.run_full_scan()
    
    # Exit with appropriate code
    if report['findings_by_severity'].get('HIGH', 0) > 0:
        sys.exit(1)
    elif report['findings_by_severity'].get('MEDIUM', 0) > 0:
        sys.exit(2)
    else:
        sys.exit(0)


if __name__ == '__main__':
    main()

