#!/usr/bin/env python3
"""
Security Advisories Checker
Fetches and checks against known compromised packages from security advisories.

Sources:
- StepSecurity Blog
- Semgrep Security Advisory
- JFrog Security Research
- Wiz Security Blog
- Socket.dev Blog (CrowdStrike package analysis)
"""

import json
import urllib.request
import urllib.error
import re
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Set

class SecurityAdvisoriesChecker:
    """Check packages against security advisories"""
    
    def __init__(self, cache_dir='.cache'):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.cache_file = self.cache_dir / 'compromised_packages.json'
        self.compromised_packages = {}
        self.cache_duration = timedelta(days=1)  # Refresh cache daily
        
    def load_cached_data(self):
        """Load compromised packages from cache - returns True if valid cache exists"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    cache_time_str = data.get('last_updated', '2000-01-01')
                    try:
                        cache_time = datetime.fromisoformat(cache_time_str)
                        if datetime.now() - cache_time < self.cache_duration:
                            return True  # Valid cache exists
                    except ValueError:
                        return False  # Invalid date format
            except Exception as e:
                print(f"Warning: Could not load cache: {e}")
        return False
    
    def save_cache(self):
        """Save compromised packages to cache"""
        try:
            data = {
                'last_updated': datetime.now().isoformat(),
                'packages': self.compromised_packages
            }
            with open(self.cache_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Warning: Could not save cache: {e}")
    
    def fetch_url(self, url, timeout=10):
        """Fetch content from URL using standard library only"""
        import ssl
        try:
            # Create SSL context that doesn't verify certificates (for compatibility)
            # Note: In production, you may want to verify certificates
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            req = urllib.request.Request(
                url,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
            )
            with urllib.request.urlopen(req, timeout=timeout, context=ssl_context) as response:
                return response.read().decode('utf-8', errors='ignore')
        except urllib.error.URLError as e:
            print(f"  Warning: Could not fetch {url}: {e}")
            return None
        except Exception as e:
            print(f"  Warning: Error fetching {url}: {e}")
            return None
    
    def extract_packages_from_text(self, text: str, source: str) -> Set[str]:
        """Extract package names from text content"""
        packages = set()
        
        # Enhanced patterns for package names in security advisories
        patterns = [
            # NPM package format with @scope
            r'@([a-zA-Z0-9_-]+)/([a-zA-Z0-9_-]+)',
            # PyPI package format
            r'pypi\.org/project/([a-zA-Z0-9_-]+)',
            # Package names in code blocks or lists
            r'`([a-zA-Z0-9@/_-]+)`',  # Backtick wrapped
            r'\*?\s*([a-zA-Z0-9@/_-]+)\s*[:\-]',  # List items
            # JSON-like structures
            r'package["\']?\s*[:=]\s*["\']([a-zA-Z0-9@/_-]+)["\']',
            r'["\']([a-zA-Z0-9@/_-]+)["\']\s*[,:\]]',  # In arrays/objects
            # Command line patterns
            r'pip\s+install\s+([a-zA-Z0-9@/_-]+)',
            r'npm\s+install\s+([a-zA-Z0-9@/_-]+)',
            # Package name patterns
            r'package:\s*([a-zA-Z0-9@/_-]+)',
            r'name:\s*["\']?([a-zA-Z0-9@/_-]+)["\']?',
            # Table/code patterns
            r'\|([a-zA-Z0-9@/_-]+)\|',  # Markdown tables
            r'<code>([a-zA-Z0-9@/_-]+)</code>',  # HTML code tags
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            # Handle tuple results from @scope/package patterns
            for match in matches:
                if isinstance(match, tuple):
                    # Combine scope and package name
                    if len(match) == 2:
                        packages.add(f"@{match[0]}/{match[1]}")
                    else:
                        packages.update(match)
                else:
                    packages.add(match)
        
        # Filter out common false positives
        false_positives = {
            'package', 'name', 'install', 'pip', 'python', 'import', 
            'npm', 'node', 'js', 'json', 'html', 'css', 'http', 'https',
            'www', 'com', 'org', 'io', 'dev', 'blog', 'security'
        }
        
        # Clean and validate packages
        cleaned_packages = set()
        for pkg in packages:
            pkg_lower = pkg.lower().strip()
            # Must be at least 2 chars, not a false positive, and look like a package name
            if (len(pkg_lower) >= 2 and 
                pkg_lower not in false_positives and
                not pkg_lower.startswith('http') and
                '/' not in pkg_lower or pkg_lower.startswith('@')):  # Allow scoped packages
                cleaned_packages.add(pkg)
        
        return cleaned_packages
    
    def check_stepsecurity_blog(self):
        """Check StepSecurity Blog for compromised packages"""
        # Specific Shai-Hulud advisory URL
        urls = [
            'https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised',
        ]
        
        packages = set()
        for url in urls:
            content = self.fetch_url(url)
            if content:
                found = self.extract_packages_from_text(content, 'StepSecurity')
                packages.update(found)
                if found:
                    print(f"  Extracted {len(found)} potential packages from {url}")
            else:
                print(f"  Warning: Could not fetch {url}")
        
        # Add packages found
        added_count = 0
        for pkg in packages:
            if pkg not in self.compromised_packages:
                self.compromised_packages[pkg] = {
                    'source': 'StepSecurity Blog - Shai-Hulud Attack',
                    'first_seen': datetime.now().isoformat(),
                    'advisory_url': 'https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised'
                }
                added_count += 1
        
        return added_count
    
    def check_semgrep_advisory(self):
        """Check Semgrep Security Advisory"""
        # Specific Shai-Hulud advisory URL
        urls = [
            'https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/',
        ]
        
        packages = set()
        for url in urls:
            content = self.fetch_url(url)
            if content:
                found = self.extract_packages_from_text(content, 'Semgrep')
                packages.update(found)
                if found:
                    print(f"  Extracted {len(found)} potential packages from {url}")
            else:
                print(f"  Warning: Could not fetch {url}")
        
        added_count = 0
        for pkg in packages:
            if pkg not in self.compromised_packages:
                self.compromised_packages[pkg] = {
                    'source': 'Semgrep Security Advisory - Shai-Hulud Attack',
                    'first_seen': datetime.now().isoformat(),
                    'advisory_url': 'https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/'
                }
                added_count += 1
        
        return added_count
    
    def check_jfrog_research(self):
        """Check JFrog Security Research"""
        # Specific Shai-Hulud advisory URL
        urls = [
            'https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/',
        ]
        
        packages = set()
        for url in urls:
            content = self.fetch_url(url)
            if content:
                found = self.extract_packages_from_text(content, 'JFrog')
                packages.update(found)
                if found:
                    print(f"  Extracted {len(found)} potential packages from {url}")
            else:
                print(f"  Warning: Could not fetch {url}")
        
        added_count = 0
        for pkg in packages:
            if pkg not in self.compromised_packages:
                self.compromised_packages[pkg] = {
                    'source': 'JFrog Security Research - Shai-Hulud Attack',
                    'first_seen': datetime.now().isoformat(),
                    'advisory_url': 'https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/'
                }
                added_count += 1
        
        return added_count
    
    def check_wiz_security(self):
        """Check Wiz Security Blog"""
        # Specific Shai-Hulud advisory URL
        urls = [
            'https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack',
        ]
        
        packages = set()
        for url in urls:
            content = self.fetch_url(url)
            if content:
                found = self.extract_packages_from_text(content, 'Wiz')
                packages.update(found)
                if found:
                    print(f"  Extracted {len(found)} potential packages from {url}")
            else:
                print(f"  Warning: Could not fetch {url}")
        
        added_count = 0
        for pkg in packages:
            if pkg not in self.compromised_packages:
                self.compromised_packages[pkg] = {
                    'source': 'Wiz Security Blog - Shai-Hulud Attack',
                    'first_seen': datetime.now().isoformat(),
                    'advisory_url': 'https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack'
                }
                added_count += 1
        
        return added_count
    
    def check_socket_dev(self):
        """Check Socket.dev Blog (CrowdStrike package analysis)"""
        # Specific Shai-Hulud advisory URL
        urls = [
            'https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages',
        ]
        
        packages = set()
        for url in urls:
            content = self.fetch_url(url)
            if content:
                found = self.extract_packages_from_text(content, 'Socket.dev')
                packages.update(found)
                if found:
                    print(f"  Extracted {len(found)} potential packages from {url}")
            else:
                print(f"  Warning: Could not fetch {url}")
        
        added_count = 0
        for pkg in packages:
            if pkg not in self.compromised_packages:
                self.compromised_packages[pkg] = {
                    'source': 'Socket.dev Blog - Shai-Hulud Attack',
                    'first_seen': datetime.now().isoformat(),
                    'advisory_url': 'https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages'
                }
                added_count += 1
        
        return added_count
    
    def load_known_compromised_packages(self):
        """Load manually curated list of known compromised packages from Shai-Hulud attack"""
        # Known compromised packages from Shai-Hulud NPM supply chain attack
        # Sources:
        # - https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised
        # - https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/
        # - https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/
        # - https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages
        # - https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack
        
        known_packages = {
            # Primary compromised package (2M+ weekly downloads)
            '@ctrl/tinycolor': {
                'source': 'StepSecurity Blog - Shai-Hulud Attack',
                'first_seen': '2025-09-15T00:00:00',
                'notes': 'Primary target, 2M+ weekly downloads, self-replicating worm',
                'advisory_url': 'https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised'
            },
            # Note: The attack compromised 500+ packages total, but specific package names
            # should be added as they are identified in the advisories.
            # The following are examples of packages that may be affected:
            # Add specific package names from the advisories as they are published
        }
        
        # Add packages from specific advisory sources
        # These should be updated as new packages are discovered
        shai_hulud_packages = [
            # Add specific package names here as they are identified
            # Example format (uncomment and add actual packages):
            # 'package-name-1',
            # 'package-name-2',
        ]
        
        for pkg in shai_hulud_packages:
            if pkg not in known_packages:
                known_packages[pkg] = {
                    'source': 'Shai-Hulud Attack - Multiple Sources',
                    'first_seen': '2025-09-15T00:00:00',
                    'notes': 'Compromised in Shai-Hulud self-replicating worm attack',
                    'attack_type': 'Self-replicating worm, credential harvesting'
                }
        
        for pkg, info in known_packages.items():
            # Always update known packages (they take precedence over cached data)
            self.compromised_packages[pkg] = info
    
    def update_advisories(self, force_refresh=False):
        """Update compromised packages from all sources"""
        # Always load known compromised packages first (hardcoded list)
        self.load_known_compromised_packages()
        print(f"Loaded {len(self.compromised_packages)} known compromised packages from hardcoded list")
        
        # Check if we have valid cached data
        if not force_refresh and self.load_cached_data():
            # Load cached packages (but don't overwrite known packages)
            try:
                with open(self.cache_file, 'r') as f:
                    cache_data = json.load(f)
                    cached_packages = cache_data.get('packages', {})
                    cache_time = self.get_cache_time()
                    print(f"Using cached data from web sources (last updated: {cache_time})")
                    # Add cached packages that aren't in known list (known packages take precedence)
                    for pkg, info in cached_packages.items():
                        if pkg not in self.compromised_packages:
                            self.compromised_packages[pkg] = info
                    print(f"Total compromised packages in database: {len(self.compromised_packages)}")
                    return len(self.compromised_packages)
            except Exception as e:
                print(f"Warning: Error loading cache: {e}, fetching from sources...")
        
        print("Fetching security advisories from all 5 sources...")
        print("=" * 60)
        print("Source 1/5: StepSecurity Blog")
        print("  URL: https://www.stepsecurity.io/blog/ctrl-tinycolor-and-40-npm-packages-compromised")
        total_found = self.check_stepsecurity_blog()
        print(f"  Added: {total_found} new packages")
        
        print("\nSource 2/5: Semgrep Security Advisory")
        print("  URL: https://semgrep.dev/blog/2025/security-advisory-npm-packages-using-secret-scanning-tools-to-steal-credentials/")
        found = self.check_semgrep_advisory()
        total_found += found
        print(f"  Added: {found} new packages")
        
        print("\nSource 3/5: JFrog Security Research")
        print("  URL: https://jfrog.com/blog/shai-hulud-npm-supply-chain-attack-new-compromised-packages-detected/")
        found = self.check_jfrog_research()
        total_found += found
        print(f"  Added: {found} new packages")
        
        print("\nSource 4/5: Wiz Security Blog")
        print("  URL: https://www.wiz.io/blog/shai-hulud-npm-supply-chain-attack")
        found = self.check_wiz_security()
        total_found += found
        print(f"  Added: {found} new packages")
        
        print("\nSource 5/5: Socket.dev Blog")
        print("  URL: https://socket.dev/blog/ongoing-supply-chain-attack-targets-crowdstrike-npm-packages")
        found = self.check_socket_dev()
        total_found += found
        print(f"  Added: {found} new packages")
        
        # Ensure known packages are still included (they take precedence)
        self.load_known_compromised_packages()
        
        self.save_cache()
        
        print("=" * 60)
        print(f"Total compromised packages in database: {len(self.compromised_packages)}")
        
        # Count known vs web-sourced packages
        known_count = sum(1 for p in self.compromised_packages.values() 
                         if 'advisory_url' in p or 'Shai-Hulud Attack' in p.get('source', ''))
        web_count = len(self.compromised_packages) - known_count
        
        print(f"  - Known packages (hardcoded): {known_count}")
        print(f"  - Packages from web sources: {web_count}")
        
        # Show known packages
        if known_count > 0:
            print(f"\n  Known compromised packages:")
            for pkg, info in self.compromised_packages.items():
                if 'advisory_url' in info or 'Shai-Hulud Attack' in info.get('source', ''):
                    print(f"    • {pkg} - {info.get('source', 'Unknown')}")
        
        # Warn if no packages found from web sources
        if web_count == 0 and total_found == 0:
            print(f"\n  ⚠️  Warning: No packages extracted from web sources.")
            print(f"     This may be due to:")
            print(f"     - Web pages requiring JavaScript rendering")
            print(f"     - Rate limiting or access restrictions")
            print(f"     - Package names in formats not detected by extraction")
            print(f"     - Network connectivity issues")
            print(f"\n     Recommendation: Manually add packages using:")
            print(f"     python3 add_compromised_packages.py --source 'Source Name' package-name")
        
        return len(self.compromised_packages)
    
    def get_cache_time(self):
        """Get cache last updated time"""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    return data.get('last_updated', 'Unknown')
            except:
                pass
        return 'No cache'
    
    def check_package(self, package_name: str) -> Dict:
        """Check if a package is in the compromised list"""
        package_lower = package_name.lower()
        
        # Check exact match
        if package_lower in self.compromised_packages:
            return {
                'compromised': True,
                'package': package_name,
                'info': self.compromised_packages[package_lower]
            }
        
        # Check partial matches (typosquatting)
        for compromised_pkg, info in self.compromised_packages.items():
            if compromised_pkg in package_lower or package_lower in compromised_pkg:
                return {
                    'compromised': True,
                    'package': package_name,
                    'match_type': 'partial',
                    'matched_package': compromised_pkg,
                    'info': info
                }
        
        return {'compromised': False, 'package': package_name}
    
    def get_all_compromised_packages(self) -> Dict:
        """Get all compromised packages"""
        return self.compromised_packages.copy()


def main():
    """Test the security advisories checker"""
    checker = SecurityAdvisoriesChecker()
    
    print("=" * 60)
    print("Security Advisories Checker")
    print("=" * 60)
    print()
    
    # Update from sources
    checker.update_advisories(force_refresh=False)
    
    print(f"\nCompromised packages database: {len(checker.compromised_packages)} packages")
    
    # Test check
    test_packages = ['requests', 'numpy', 'malicious-package']
    print("\nTesting package checks:")
    for pkg in test_packages:
        result = checker.check_package(pkg)
        if result['compromised']:
            print(f"  ⚠ {pkg}: COMPROMISED - {result.get('info', {}).get('source', 'Unknown')}")
        else:
            print(f"  ✓ {pkg}: Safe")


if __name__ == '__main__':
    main()

