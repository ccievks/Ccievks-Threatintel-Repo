# Shai-Hulud Detector

A security tool to detect malware and compromised packages in your local environment.

## Features

- Scans installed Python packages for suspicious patterns
- Checks package integrity and signatures
- Detects suspicious file modifications
- Scans for known malware indicators
- Validates package checksums
- **Checks against security advisories from:**
  - StepSecurity Blog
  - Semgrep Security Advisory
  - JFrog Security Research
  - Wiz Security Blog
  - Socket.dev Blog (CrowdStrike package analysis)
- Reports potential security issues

## Usage

### Step 1: Verify Environment (Recommended)
Before running the detector, verify your environment is safe:
```bash
python verify_environment.py
```

### Step 2: Update Security Advisories (Optional)
Update the compromised packages database:
```bash
python update_advisories.py
```

### Step 2a: Add Known Compromised Packages (Manual)
If you find specific compromised packages in advisories, add them manually:
```bash
python add_compromised_packages.py --source "StepSecurity Blog" --notes "Shai-Hulud attack" @ctrl/tinycolor package-name-2
```

### Step 3: Run the Detector
```bash
python shai_hulud_detector.py
```

The detector will:
1. Check all installed packages against security advisories
2. **Only report known compromised packages** (filters out false positives)
3. If compromised packages found, run additional checks:
   - Validate package integrity
   - Scan site-packages for suspicious files
   - Check environment variables
4. Generate a detailed JSON report

**Note**: The report only includes known compromised packages from security advisories. Pattern-based findings for legitimate packages are filtered out to avoid confusion.

### Output
- Console output with real-time findings
- JSON report file: `shai_hulud_report_YYYYMMDD_HHMMSS.json`

## Requirements

- Python 3.7+
- Standard library only (no external dependencies to avoid compromise)

## Security Note

This tool uses only Python standard library to avoid installing potentially compromised packages.

