# Step-by-Step Execution Guide

## Quick Execution (Recommended)

### Step 1: Navigate to the detector directory
```bash
cd /Users/vikaskataria/Downloads/Cursor/shai-hulud-detector
```

### Step 2: Run the detector
```bash
python3 shai_hulud_detector.py
```

That's it! The detector will:
- ✅ Load known compromised packages
- ✅ Update from 5 security advisory sources
- ✅ Scan all your installed packages
- ✅ Generate a report

---

## Detailed Execution Steps

### Step 1: Verify Environment (Optional but Recommended)
```bash
cd /Users/vikaskataria/Downloads/Cursor/shai-hulud-detector
python3 verify_environment.py
```

**Expected Output:**
```
✓ Python version: 3.x.x
✓ Standard library modules available
✓ pip available: pip x.x.x
✓ No suspicious modules found
✓ Environment verification passed
```

### Step 2: Run the Full Scan
```bash
python3 shai_hulud_detector.py
```

**What happens:**
1. Updates compromised packages database from 5 sources
2. Scans all installed Python packages
3. Checks against compromised packages list
4. Generates report

**Expected Output:**
```
============================================================
Shai-Hulud Detector - Malware Detection Scan
============================================================
Scan started at: 2025-11-25T...

Step 0: Updating compromised packages database...
  - Loading known compromised packages from hardcoded list
  - Fetching latest packages from 5 security advisory sources

Loaded 1 known compromised packages from hardcoded list
Using cached data from web sources (last updated: ...)
Total compromised packages in database: 1

✓ Compromised packages database ready: 1 packages

Step 1: Retrieving installed packages...
Found 73 installed packages

Step 2: Scanning packages for suspicious content...
Scanning: annotated-types (0.7.0)
Scanning: anyio (4.11.0)
...

============================================================
Scan Complete - Generating Report
============================================================

Summary:
  Packages scanned: 73
  Compromised packages found: 0

  ✓ No compromised packages detected!
  Note: Pattern-based findings for legitimate packages have been filtered out.

Detailed report saved to: shai_hulud_report_20251125_171418.json
```

### Step 3: Review the Report

The report is saved as: `shai_hulud_report_YYYYMMDD_HHMMSS.json`

View it:
```bash
# View the report
cat shai_hulud_report_*.json | python3 -m json.tool | less

# Or open in your editor
open shai_hulud_report_*.json
```

---

## Alternative: Manual Update First

If you want to update the database separately:

### Step 1: Update Security Advisories
```bash
cd /Users/vikaskataria/Downloads/Cursor/shai-hulud-detector
python3 update_advisories.py
```

### Step 2: Run the Detector
```bash
python3 shai_hulud_detector.py
```

---

## If Compromised Packages Are Found

If the detector finds compromised packages, you'll see:

```
⚠️  COMPROMISED PACKAGES DETECTED:
  - @ctrl/tinycolor (1.0.0)
    Source: StepSecurity Blog - Shai-Hulud Attack
```

**Immediate Actions:**
1. **Rotate ALL credentials immediately**:
   - NPM tokens
   - GitHub personal access tokens
   - AWS/GCP/Azure credentials
   - SSH keys

2. **Remove compromised packages**:
   ```bash
   pip uninstall <package-name>
   ```

3. **Review the detailed report** for more information

4. **See KNOWN_COMPROMISED_PACKAGES.md** for remediation steps

---

## Command Reference

| Command | Purpose |
|---------|---------|
| `python3 verify_environment.py` | Verify environment is safe |
| `python3 shai_hulud_detector.py` | Run full security scan |
| `python3 update_advisories.py` | Update compromised packages database |
| `python3 add_compromised_packages.py <pkg1> <pkg2>` | Manually add compromised packages |
| `python3 security_advisories.py` | Test advisories checker |

---

## Troubleshooting

### Permission Errors
```bash
# If you get permission errors, check file permissions
chmod +x shai_hulud_detector.py
```

### Import Errors
```bash
# Make sure you're in the correct directory
cd /Users/vikaskataria/Downloads/Cursor/shai-hulud-detector
python3 shai_hulud_detector.py
```

### Network Issues
If you can't fetch from web sources, the detector will:
- Use cached data if available
- Still check against known compromised packages
- Continue with the scan

---

## Expected Runtime

- **First run**: 2-5 minutes (fetches from web sources)
- **Subsequent runs**: 30 seconds - 2 minutes (uses cache)
- **Scan time**: Depends on number of installed packages (~1-2 seconds per package)

---

## Next Steps After Scan

1. **Review the report** for any compromised packages
2. **If clean**: Run weekly or after installing new packages
3. **If compromised**: Follow remediation steps in `KNOWN_COMPROMISED_PACKAGES.md`
4. **Update regularly**: Run `python3 update_advisories.py` weekly to get latest threats

